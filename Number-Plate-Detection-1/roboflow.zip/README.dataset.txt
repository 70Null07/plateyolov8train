# Number Plate Detection > 2024-02-28 9:51pm
https://universe.roboflow.com/snowy-car-detection/number-plate-detection-c3hto

Provided by a Roboflow user
License: MIT

